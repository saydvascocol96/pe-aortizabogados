import RootLayout from '@/components/layout/RootLayout';
import { motion } from 'framer-motion';
import { Quote, Star } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const testimonials = [
  {
    quote: "Desde el primer momento me sentí escuchado y respaldado. El equipo de Lex Veritas fue increíblemente profesional y eficiente. ¡Los recomiendo totalmente!",
    author: "Carlos G.",
    role: "Cliente de Derecho Laboral",
    avatar: "https://storage.googleapis.com/fenado-ai-farm-public/generated/929b4402-89c4-4df6-9445-2e76d62e1396.webp",
    stars: 5,
    date: "Junio 2025"
  },
  {
    quote: "Afrontar un proceso de divorcio fue muy duro, pero ellos me guiaron con una empatía y una claridad que agradecí enormemente. Me dieron la tranquilidad que necesitaba.",
    author: "María L.",
    role: "Cliente de Derecho de Familia",
    avatar: "https://storage.googleapis.com/fenado-ai-farm-public/generated/d112f920-d6d9-4891-bfd4-216a47cd5d67.webp",
    stars: 5,
    date: "Mayo 2025"
  },
  {
    quote: "Necesitábamos un asesoramiento mercantil rápido y preciso para nuestra startup. Su conocimiento y agilidad fueron clave para nosotros. Excelentes profesionales.",
    author: "Proyectos Tech S.L.",
    role: "Cliente de Derecho Comercial",
    avatar: "https://storage.googleapis.com/fenado-ai-farm-public/generated/d15d24e8-2083-4093-8abd-2d4364077195.webp",
    stars: 5,
    date: "Abril 2025"
  },
  {
    quote: "Cuando tuve problemas con mi arrendador, no sabía qué hacer. Gracias a su asesoramiento profesional, pude resolver la situación de manera favorable. Estoy muy agradecido por su ayuda.",
    author: "Miguel A.",
    role: "Cliente de Derecho Civil",
    avatar: "https://storage.googleapis.com/fenado-ai-farm-public/generated/929b4402-89c4-4df6-9445-2e76d62e1396.webp",
    stars: 5,
    date: "Marzo 2025"
  },
  {
    quote: "Llevaba años sin poder resolver un problema con una herencia familiar. En apenas unos meses, el equipo de Lex Veritas consiguió desbloquear la situación. Su experiencia en derecho sucesorio es impresionante.",
    author: "Elena R.",
    role: "Cliente de Derecho Civil",
    avatar: "https://storage.googleapis.com/fenado-ai-farm-public/generated/d112f920-d6d9-4891-bfd4-216a47cd5d67.webp",
    stars: 4,
    date: "Febrero 2025"
  },
  {
    quote: "Como empresa, valoramos enormemente la claridad y eficacia con la que nos han asesorado en materia laboral. Han sido fundamentales para ayudarnos a implementar los cambios normativos recientes.",
    author: "Industrias González S.A.",
    role: "Cliente de Derecho Laboral",
    avatar: "https://storage.googleapis.com/fenado-ai-farm-public/generated/d15d24e8-2083-4093-8abd-2d4364077195.webp",
    stars: 5,
    date: "Enero 2025"
  }
];

const Testimonios = () => {
  return (
    <RootLayout>
      <div className="bg-muted py-20 mt-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold font-['Raleway'] mb-4 text-gradient">
              Testimonios de Clientes
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Descubra lo que nuestros clientes opinan sobre nuestros servicios y cómo les hemos ayudado a resolver sus problemas legales.
            </p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="testimonial-card h-full flex flex-col"
            >
              <div className="mb-4">
                <Quote className="text-accent/40 mb-2" size={40} />
                <p className="text-foreground/90 italic mb-6">
                  "{testimonial.quote}"
                </p>
              </div>

              <div className="mt-auto">
                <div className="flex mb-3">
                  {Array.from({ length: testimonial.stars }).map((_, i) => (
                    <Star key={i} className="text-accent fill-accent" size={16} />
                  ))}
                  {Array.from({ length: 5 - testimonial.stars }).map((_, i) => (
                    <Star key={i} className="text-muted-foreground/30" size={16} />
                  ))}
                </div>

                <div className="flex items-center gap-3">
                  <Avatar className="w-12 h-12 border-2 border-border">
                    <AvatarImage src={testimonial.avatar} alt={testimonial.author} />
                    <AvatarFallback className="bg-primary text-primary-foreground">
                      {testimonial.author.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-semibold font-['Raleway']">
                      {testimonial.author}
                    </p>
                    <div className="flex items-center justify-between gap-4">
                      <p className="text-sm text-muted-foreground">
                        {testimonial.role}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {testimonial.date}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-20 bg-card border border-border rounded-lg p-8 shadow-md">
          <h2 className="text-2xl font-semibold font-['Raleway'] mb-6 text-center">
            ¿Por qué nuestros clientes nos eligen?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-4">
              <div className="bg-primary/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <span className="text-primary font-semibold text-xl">95%</span>
              </div>
              <h3 className="font-semibold mb-2">Tasa de Éxito</h3>
              <p className="text-muted-foreground text-sm">En casos resueltos favorablemente para nuestros clientes.</p>
            </div>
            <div className="text-center p-4">
              <div className="bg-primary/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <span className="text-primary font-semibold text-xl">+500</span>
              </div>
              <h3 className="font-semibold mb-2">Clientes Satisfechos</h3>
              <p className="text-muted-foreground text-sm">Que han confiado en nuestros servicios legales.</p>
            </div>
            <div className="text-center p-4">
              <div className="bg-primary/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <span className="text-primary font-semibold text-xl">15</span>
              </div>
              <h3 className="font-semibold mb-2">Años de Experiencia</h3>
              <p className="text-muted-foreground text-sm">Ofreciendo soluciones legales de calidad.</p>
            </div>
          </div>
        </div>
      </div>
    </RootLayout>
  );
};

export default Testimonios;