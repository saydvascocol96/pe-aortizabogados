import RootLayout from '@/components/layout/RootLayout';
import ContactSection from '@/components/home/ContactSection';

const Contacto = () => {
  return (
    <RootLayout>
      <div className="pt-16">
        <ContactSection />
      </div>
    </RootLayout>
  );
};

export default Contacto;