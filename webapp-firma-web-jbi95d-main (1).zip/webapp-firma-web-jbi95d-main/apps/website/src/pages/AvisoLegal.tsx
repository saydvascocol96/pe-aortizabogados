import RootLayout from '@/components/layout/RootLayout';

const AvisoLegal = () => {
  return (
    <RootLayout>
      <div className="bg-muted py-20">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold font-['Raleway'] text-center mb-6 text-gradient">
            Aviso Legal
          </h1>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto prose prose-lg">
          <h2>Información General</h2>
          <p>
            En cumplimiento con el deber de información recogido en el artículo 10 de la Ley 34/2002, de 11 de julio, de Servicios de la Sociedad de la Información y del Comercio Electrónico, le informamos que el sitio web y el dominio www.lexveritas.es es propiedad de Lex Veritas Abogados S.L.P., con NIF B-00000000 y domicilio social en Calle Ficticia 123, 28080, Madrid, España. Inscrita en el Registro Mercantil de Madrid, Tomo XXXXX, Folio XXX, Hoja M-XXXXXX.
          </p>

          <h2>Objeto y Ámbito de Aplicación</h2>
          <p>
            Las presentes condiciones regulan el uso del sitio web www.lexveritas.es, que Lex Veritas Abogados S.L.P. pone a disposición de los usuarios de Internet. La navegación por el sitio web atribuye la condición de usuario del mismo e implica la aceptación plena y sin reservas de todas y cada una de las disposiciones incluidas en este Aviso Legal.
          </p>

          <h2>Propiedad Intelectual e Industrial</h2>
          <p>
            Los derechos de propiedad intelectual del contenido de las páginas web, su diseño gráfico y códigos son titularidad de Lex Veritas Abogados S.L.P., y por tanto queda prohibida su reproducción, distribución, comunicación pública, transformación o cualquier otra actividad que se pueda realizar con los contenidos de sus páginas web ni aun citando las fuentes, salvo consentimiento por escrito de Lex Veritas Abogados S.L.P.
          </p>

          <h2>Exención de Responsabilidades</h2>
          <p>
            Lex Veritas Abogados S.L.P. declina cualquier responsabilidad respecto a la información que se halle fuera de esta web y no sea gestionada directamente por nuestro webmaster. La función de los links que aparecen en esta web es exclusivamente la de informar al usuario sobre la existencia de otras fuentes susceptibles de ampliar los contenidos que ofrece este sitio web.
          </p>

          <h2>Política de Privacidad</h2>
          <p>
            Lex Veritas Abogados S.L.P. garantiza la confidencialidad de los datos de carácter personal facilitados por los usuarios y su tratamiento automatizado de acuerdo con la legislación vigente sobre protección de datos de carácter personal (Ley Orgánica 3/2018, de 5 de diciembre, de Protección de Datos Personales y garantía de los derechos digitales y Reglamento UE 2016/679).
          </p>

          <h2>Ley Aplicable y Jurisdicción</h2>
          <p>
            Para la resolución de todas las controversias o cuestiones relacionadas con el presente sitio web o de las actividades en él desarrolladas, será de aplicación la legislación española, a la que se someten expresamente las partes, siendo competentes para la resolución de todos los conflictos derivados o relacionados con su uso los Juzgados y Tribunales de Madrid.
          </p>

          <p className="text-sm text-muted-foreground mt-8">
            Última actualización: Agosto de 2025
          </p>
        </div>
      </div>
    </RootLayout>
  );
};

export default AvisoLegal;