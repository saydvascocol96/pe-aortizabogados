import RootLayout from '@/components/layout/RootLayout';

const Privacidad = () => {
  return (
    <RootLayout>
      <div className="bg-muted py-20">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold font-['Raleway'] text-center mb-6 text-gradient">
            Política de Privacidad
          </h1>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto prose prose-lg">
          <h2>Información básica sobre protección de datos</h2>
          <p>
            En cumplimiento del Reglamento (UE) 2016/679 del Parlamento Europeo y del Consejo de 27 de abril de 2016, relativo a la protección de las personas físicas en lo que respecta al tratamiento de datos personales y a la libre circulación de estos datos (RGPD) y la Ley Orgánica 3/2018, de 5 de diciembre, de Protección de Datos Personales y garantía de los derechos digitales, se informa al usuario que los datos personales que proporcione serán tratados por Lex Veritas Abogados S.L.P.
          </p>

          <h2>Responsable del tratamiento</h2>
          <ul>
            <li><strong>Identidad:</strong> Lex Veritas Abogados S.L.P.</li>
            <li><strong>Dirección postal:</strong> Calle Ficticia 123, 28080, Madrid, España</li>
            <li><strong>Teléfono:</strong> +34 912 345 678</li>
            <li><strong>Email:</strong> privacidad@lexveritas.es</li>
          </ul>

          <h2>Finalidad del tratamiento</h2>
          <p>
            Los datos personales que nos proporcione serán utilizados con la finalidad de:
          </p>
          <ul>
            <li>Gestionar la relación contractual y precontractual con nuestros clientes.</li>
            <li>Atender consultas, solicitudes o peticiones realizadas a través del formulario de contacto o por correo electrónico.</li>
            <li>Enviar comunicaciones comerciales sobre nuestros servicios, siempre que haya prestado su consentimiento para ello.</li>
            <li>Cumplir con obligaciones legales.</li>
          </ul>

          <h2>Legitimación</h2>
          <p>
            La base legal para el tratamiento de sus datos es:
          </p>
          <ul>
            <li>La ejecución de un contrato en el que el interesado es parte o la aplicación de medidas precontractuales.</li>
            <li>El consentimiento del interesado para el tratamiento de sus datos personales para uno o varios fines específicos.</li>
            <li>El cumplimiento de una obligación legal aplicable al responsable del tratamiento.</li>
            <li>El interés legítimo del responsable del tratamiento o de un tercero.</li>
          </ul>

          <h2>Destinatarios</h2>
          <p>
            Sus datos podrán ser comunicados a:
          </p>
          <ul>
            <li>Administraciones Públicas en los casos previstos por la Ley.</li>
            <li>Entidades financieras para la gestión de cobros y pagos.</li>
            <li>Encargados del tratamiento necesarios para la prestación del servicio.</li>
          </ul>
          <p>
            No se realizarán transferencias internacionales de datos.
          </p>

          <h2>Derechos</h2>
          <p>
            El usuario puede ejercer los siguientes derechos:
          </p>
          <ul>
            <li>Acceso: conocer qué datos personales están siendo tratados.</li>
            <li>Rectificación: modificar los datos inexactos o incompletos.</li>
            <li>Supresión: solicitar la eliminación de los datos cuando, entre otros motivos, ya no sean necesarios.</li>
            <li>Limitación del tratamiento: solicitar la limitación del tratamiento de los datos en determinadas circunstancias.</li>
            <li>Portabilidad: recibir los datos personales en un formato estructurado y transmitirlos a otro responsable.</li>
            <li>Oposición: oponerse al tratamiento de los datos en determinadas circunstancias.</li>
          </ul>
          <p>
            Estos derechos pueden ejercerse enviando un correo electrónico a privacidad@lexveritas.es o mediante carta dirigida a la dirección postal indicada anteriormente, adjuntando en ambos casos copia del DNI u otro documento identificativo.
          </p>

          <h2>Conservación de datos</h2>
          <p>
            Los datos personales se conservarán mientras se mantenga la relación contractual, no se solicite su supresión por el interesado y no deban eliminarse por obligación legal o interés legítimo del responsable.
          </p>

          <h2>Medidas de seguridad</h2>
          <p>
            Lex Veritas Abogados S.L.P. ha adoptado las medidas técnicas y organizativas necesarias para garantizar la seguridad de los datos de carácter personal y evitar su alteración, pérdida, tratamiento o acceso no autorizado.
          </p>

          <h2>Modificación de la política de privacidad</h2>
          <p>
            Lex Veritas Abogados S.L.P. se reserva el derecho a modificar la presente política para adaptarla a novedades legislativas o jurisprudenciales. En dichos supuestos, anunciará en esta página los cambios introducidos con razonable antelación a su puesta en práctica.
          </p>

          <p className="text-sm text-muted-foreground mt-8">
            Última actualización: Agosto de 2025
          </p>
        </div>
      </div>
    </RootLayout>
  );
};

export default Privacidad;