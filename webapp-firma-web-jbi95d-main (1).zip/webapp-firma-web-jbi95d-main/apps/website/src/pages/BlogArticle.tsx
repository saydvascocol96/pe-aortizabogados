import { useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import RootLayout from '@/components/layout/RootLayout';
import { ArrowLeft, CalendarIcon, Clock, UserCircle, Share2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog';
import ContactForm from '@/components/ContactForm';
import { Separator } from '@/components/ui/separator';

// Sample blog articles data
const blogArticles = [
  {
    id: 'registro-horario-laboral',
    title: '5 Claves sobre el nuevo registro horario en el trabajo',
    excerpt: 'El registro de jornada laboral es obligatorio en España desde mayo de 2019. Conoce las claves principales para cumplir con esta normativa y evitar sanciones para tu empresa.',
    image: 'https://storage.googleapis.com/fenado-ai-farm-public/generated/d15d24e8-2083-4093-8abd-2d4364077195.webp',
    date: '12 agosto, 2025',
    readTime: '5 min lectura',
    author: 'Carlos Rodríguez',
    authorRole: 'Especialista en Derecho Laboral',
    content: `
      <p>Desde la entrada en vigor del Real Decreto-ley 8/2019, de 8 de marzo, todas las empresas en España están obligadas a llevar un registro diario de la jornada laboral de sus trabajadores. Esta medida, que generó debate en su momento, busca combatir la precariedad laboral y el exceso de horas extras no remuneradas.</p>
      
      <h2>1. Obligatoriedad del registro</h2>
      <p>La normativa establece que <strong>todas las empresas, sin excepción</strong>, deben registrar diariamente la jornada de trabajo de cada empleado. Este registro debe incluir el horario concreto de inicio y finalización de la jornada laboral de cada persona trabajadora.</p>
      
      <h2>2. Métodos válidos para el registro</h2>
      <p>La ley no especifica un método concreto para realizar este registro, lo que permite a las empresas elegir el sistema que mejor se adapte a sus necesidades: aplicaciones móviles, sistemas biométricos, hojas de firma en papel o sistemas digitales. Lo importante es que el método elegido sea fiable y no manipulable.</p>
      
      <h2>3. Conservación de los registros</h2>
      <p>Los registros deben conservarse durante un periodo de <strong>cuatro años</strong>, permaneciendo a disposición de los trabajadores, sus representantes legales y la Inspección de Trabajo. Esta obligación de conservación es fundamental para poder verificar el cumplimiento de la normativa.</p>
      
      <h2>4. Sanciones por incumplimiento</h2>
      <p>Las empresas que incumplan con la obligación de registro horario pueden enfrentarse a sanciones que oscilan entre los 751 euros y los 7.500 euros, dependiendo de la gravedad de la infracción. Además, podrían enfrentarse a reclamaciones por parte de los trabajadores por horas extraordinarias no pagadas.</p>
      
      <h2>5. Beneficios del registro horario</h2>
      <p>Más allá de la obligación legal, el registro horario ofrece beneficios tanto para trabajadores como para empresas:</p>
      <ul>
        <li>Mayor transparencia en las relaciones laborales</li>
        <li>Control efectivo del tiempo de trabajo</li>
        <li>Mejor conciliación de la vida laboral y personal</li>
        <li>Reducción de conflictos relacionados con las horas extraordinarias</li>
        <li>Mejora de la productividad al optimizar los tiempos de trabajo</li>
      </ul>
      
      <p>La implementación adecuada del sistema de registro horario no solo evita sanciones, sino que puede convertirse en una herramienta útil para la gestión de recursos humanos y la mejora del clima laboral.</p>
      
      <h2>Conclusión</h2>
      <p>El registro horario ha llegado para quedarse y, lejos de ser una simple carga administrativa, puede suponer una oportunidad para mejorar la gestión del tiempo en las organizaciones. Las empresas que aún no hayan implementado un sistema de registro deberían hacerlo cuanto antes para evitar posibles sanciones y aprovechar las ventajas que ofrece esta herramienta.</p>
    `,
    category: 'laboral'
  },
  {
    id: 'notificacion-judicial',
    title: '¿Qué hacer si recibes una notificación del juzgado?',
    excerpt: 'Recibir una notificación judicial puede ser una experiencia estresante. Te explicamos los pasos a seguir y cómo actuar correctamente para proteger tus derechos.',
    image: 'https://storage.googleapis.com/fenado-ai-farm-public/generated/8e54e379-a992-41b2-87c8-056fe5ea8019.webp',
    date: '5 agosto, 2025',
    readTime: '7 min lectura',
    author: 'Laura Martínez',
    authorRole: 'Abogada Procesalista',
    content: `
      <p>Recibir una notificación judicial es una situación que puede generar ansiedad y confusión, especialmente si nunca antes has tenido contacto con el sistema judicial. Sin embargo, mantener la calma y saber cómo actuar puede marcar una gran diferencia en el desarrollo del procedimiento.</p>
      
      <h2>Comprende el tipo de notificación recibida</h2>
      <p>Las notificaciones judiciales pueden ser de diversos tipos: citaciones para comparecer, emplazamientos para contestar a una demanda, requerimientos para realizar alguna acción, o simplemente comunicaciones informativas. El primer paso es identificar claramente qué tipo de notificación has recibido y qué se te está pidiendo.</p>
      
      <h2>Verifica todos los datos</h2>
      <p>Comprueba que la notificación está dirigida efectivamente a ti. Revisa que tu nombre y DNI/NIF sean correctos. En ocasiones pueden producirse errores en las notificaciones que podrían invalidarlas.</p>
      
      <h2>Presta atención a los plazos</h2>
      <p>Uno de los aspectos más críticos de las notificaciones judiciales son los plazos. Estos suelen ser improrrogables y su incumplimiento puede tener consecuencias graves como la preclusión (pérdida del derecho a realizar un acto procesal) o incluso una sentencia en rebeldía si se trata de un emplazamiento para contestar a una demanda.</p>
      
      <h2>Busca asesoramiento legal de inmediato</h2>
      <p>Ante cualquier notificación judicial, lo más recomendable es consultar con un abogado lo antes posible. Un profesional podrá interpretar correctamente el documento, explicarte sus implicaciones y asesorarte sobre los pasos a seguir.</p>
      
      <h2>No ignores la notificación</h2>
      <p>Ignorar una notificación judicial nunca es una buena idea. El procedimiento continuará su curso con o sin tu participación, y generalmente las consecuencias de no comparecer o no responder son peores que hacerlo, incluso si crees que la reclamación o acusación es infundada.</p>
      
      <h2>Reúne documentación relevante</h2>
      <p>Dependiendo del tipo de procedimiento, será útil recopilar cualquier documento que pueda ser relevante para tu defensa: contratos, facturas, recibos, correos electrónicos, mensajes, fotografías, etc.</p>
      
      <h2>Considera la posibilidad de acuerdos extrajudiciales</h2>
      <p>En muchos casos, especialmente en asuntos civiles, es posible llegar a un acuerdo con la otra parte antes de continuar con el proceso judicial. Tu abogado podrá asesorarte sobre si esta es una opción viable en tu caso y las posibles ventajas que podría tener.</p>
      
      <h2>Prepárate para posibles comparecencias</h2>
      <p>Si la notificación incluye una citación para comparecer ante el juzgado, prepárate adecuadamente con tu abogado. Repasa lo que vas a decir, viste de manera apropiada y llega con tiempo suficiente.</p>
      
      <h2>Conclusión</h2>
      <p>Recibir una notificación judicial no tiene por qué ser motivo de pánico. Con la actitud adecuada y el asesoramiento profesional correcto, podrás afrontar el proceso con garantías. Recuerda que el sistema judicial, aunque a veces pueda parecer intimidante, está diseñado para garantizar los derechos de todas las partes implicadas.</p>
    `,
    category: 'civil'
  },
  {
    id: 'herencias-testamentos',
    title: 'Herencias y testamentos: cómo planificar el futuro',
    excerpt: 'La planificación sucesoria es fundamental para garantizar que tus bienes se distribuyan según tus deseos. Descubre las opciones legales disponibles y los beneficios fiscales.',
    image: 'https://storage.googleapis.com/fenado-ai-farm-public/generated/9c0b1b18-096b-401d-952f-d5b672b35649.webp',
    date: '29 julio, 2025',
    readTime: '8 min lectura',
    author: 'Ana García',
    authorRole: 'Especialista en Derecho Sucesorio',
    content: `
      <p>Planificar lo que ocurrirá con nuestro patrimonio después de nuestro fallecimiento es un acto de responsabilidad hacia nuestros seres queridos. Una adecuada planificación sucesoria no solo garantiza que nuestros bienes se distribuyan conforme a nuestros deseos, sino que también puede minimizar conflictos familiares y optimizar la carga fiscal para los herederos.</p>
      
      <h2>El testamento: la base de la planificación sucesoria</h2>
      <p>El testamento es el documento legal por excelencia para expresar nuestra voluntad sobre el destino de nuestros bienes. En España, existen diferentes tipos de testamentos:</p>
      
      <ul>
        <li><strong>Testamento abierto:</strong> Es el más común. Se otorga ante notario, quien redacta el documento según la voluntad del testador.</li>
        <li><strong>Testamento cerrado:</strong> El testador lo redacta en privado y lo entrega al notario en un sobre sellado.</li>
        <li><strong>Testamento ológrafo:</strong> Escrito íntegramente a mano por el testador, debe ser validado judicialmente tras el fallecimiento.</li>
      </ul>
      
      <p>El testamento abierto es generalmente la opción más recomendable por su seguridad jurídica y la garantía de que cumple con todos los requisitos legales.</p>
      
      <h2>Legítimas y libertad de testar</h2>
      <p>En España, la libertad para disponer de los bienes está limitada por el sistema de legítimas, que reserva una parte del patrimonio a determinados herederos forzosos (descendientes, ascendientes y cónyuge). Sin embargo, existen diferencias significativas entre las distintas comunidades autónomas, especialmente en territorios con derecho foral propio como Cataluña, Navarra o País Vasco, donde la libertad de testar es mayor.</p>
      
      <h2>Herramientas para la planificación sucesoria</h2>
      <p>Además del testamento, existen otras herramientas legales que pueden ser útiles en la planificación sucesoria:</p>
      
      <ul>
        <li><strong>Donaciones en vida:</strong> Permiten anticipar la transmisión de bienes, pudiendo en algunos casos obtener ventajas fiscales.</li>
        <li><strong>Pactos sucesorios:</strong> En las comunidades donde están permitidos, permiten acordar en vida aspectos relacionados con la herencia.</li>
        <li><strong>Seguros de vida:</strong> Pueden ser una forma eficiente de transmitir capital, con un tratamiento fiscal específico.</li>
        <li><strong>Constitución de sociedades familiares:</strong> Facilitan la transmisión ordenada de negocios familiares.</li>
      </ul>
      
      <h2>Fiscalidad de las herencias</h2>
      <p>El Impuesto sobre Sucesiones y Donaciones varía considerablemente entre comunidades autónomas. Una buena planificación puede aprovechar las reducciones y bonificaciones existentes:</p>
      
      <ul>
        <li>Reducciones por parentesco</li>
        <li>Reducciones por transmisión de empresa familiar</li>
        <li>Reducciones por transmisión de vivienda habitual</li>
        <li>Bonificaciones específicas según la comunidad autónoma</li>
      </ul>
      
      <h2>La importancia del inventario de bienes</h2>
      <p>Mantener un inventario actualizado de bienes y deudas, así como información sobre dónde se encuentran documentos importantes (escrituras, pólizas de seguros, cuentas bancarias), facilitará enormemente la labor de los herederos.</p>
      
      <h2>Previsiones no patrimoniales</h2>
      <p>La planificación sucesoria no se limita a aspectos económicos. También puede incluir disposiciones sobre aspectos como:</p>
      
      <ul>
        <li>Voluntades sobre el funeral y destino de los restos</li>
        <li>Nombramiento de tutores para hijos menores</li>
        <li>Instrucciones sobre el cuidado de mascotas</li>
        <li>Legado digital (qué hacer con cuentas en redes sociales, etc.)</li>
      </ul>
      
      <h2>Conclusión</h2>
      <p>La planificación sucesoria no debe posponerse. Independientemente de la edad o el patrimonio, tener previsto el destino de nuestros bienes es un acto de responsabilidad que aporta tranquilidad y evita problemas futuros a nuestros seres queridos. Contar con el asesoramiento de profesionales especializados es fundamental para diseñar la estrategia más adecuada a cada situación personal y familiar.</p>
    `,
    category: 'familia'
  }
];

const BlogArticle = () => {
  const { articleId } = useParams();
  const navigate = useNavigate();
  
  // Find the article with matching ID
  const article = blogArticles.find(article => article.id === articleId);
  
  // If article not found, redirect to blog page
  useEffect(() => {
    if (!article) {
      navigate('/blog');
    }
  }, [article, navigate]);

  if (!article) return null;

  return (
    <RootLayout>
      <div className="bg-muted py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <Button 
              variant="outline" 
              className="mb-6 flex items-center gap-2"
              onClick={() => navigate('/blog')}
            >
              <ArrowLeft size={16} />
              Volver al blog
            </Button>

            <h1 className="text-3xl md:text-4xl font-bold font-['Raleway'] mb-6">
              {article.title}
            </h1>

            <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-muted-foreground mb-8">
              <div className="flex items-center gap-2">
                <UserCircle size={18} />
                <span>{article.author}</span>
              </div>
              <div className="flex items-center gap-2">
                <CalendarIcon size={18} />
                <span>{article.date}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock size={18} />
                <span>{article.readTime}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="mb-10 rounded-lg overflow-hidden shadow-md">
            <img 
              src={article.image} 
              alt={article.title} 
              className="w-full h-auto"
            />
          </div>

          <div className="prose prose-lg max-w-none mb-12" dangerouslySetInnerHTML={{ __html: article.content }} />

          <Separator className="my-12" />

          <div className="bg-muted rounded-lg p-8 mb-12">
            <h3 className="text-2xl font-semibold font-['Raleway'] mb-4">
              ¿Necesita asesoramiento sobre este tema?
            </h3>
            <p className="text-muted-foreground mb-6">
              Nuestro equipo de abogados especializados puede ayudarle a resolver sus dudas y ofrecerle la mejor solución legal para su caso.
            </p>
            <Dialog>
              <DialogTrigger asChild>
                <Button className="legal-btn">
                  Agendar Cita
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <div className="space-y-4">
                  <h2 className="text-2xl font-semibold text-foreground">Agende su Cita</h2>
                  <p className="text-muted-foreground">Complete el formulario para una primera consulta sin compromiso. Su información es confidencial.</p>
                  <ContactForm isAppointment={true} />
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-muted-foreground">Compartir artículo:</p>
              <div className="flex gap-4 mt-2">
                <Button variant="outline" size="icon" className="rounded-full">
                  <Share2 size={16} />
                </Button>
              </div>
            </div>
            <Button 
              variant="outline" 
              className="flex items-center gap-2"
              onClick={() => navigate('/blog')}
            >
              <ArrowLeft size={16} />
              Volver al blog
            </Button>
          </div>
        </div>
      </div>
    </RootLayout>
  );
};

export default BlogArticle;