import RootLayout from '@/components/layout/RootLayout';
import HeroSection from '@/components/home/HeroSection';
import ServicesSection from '@/components/home/ServicesSection';
import AboutSection from '@/components/home/AboutSection';
import TestimonialsSection from '@/components/home/TestimonialsSection';
import CtaSection from '@/components/home/CtaSection';
import ContactSection from '@/components/home/ContactSection';

export default function Home() {
  return (
    <RootLayout>
      <HeroSection />
      <ServicesSection />
      <AboutSection />
      <TestimonialsSection />
      <CtaSection />
      <ContactSection />
    </RootLayout>
  );
}