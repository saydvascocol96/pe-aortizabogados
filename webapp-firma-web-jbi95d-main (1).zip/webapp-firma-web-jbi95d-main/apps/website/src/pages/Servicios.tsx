import RootLayout from '@/components/layout/RootLayout';
import { motion } from 'framer-motion';
import { 
  Gavel, 
  Scale, 
  Briefcase, 
  Users, 
  HeartHandshake, 
  FileSearch, 
  CheckCircle, 
  Building, 
  Landmark, 
  Banknote
} from 'lucide-react';
import AppointmentDialog from '@/components/dialogs/AppointmentDialog';
import { Button } from '@/components/ui/button';

const mainServices = [
  {
    title: 'Derecho Penal',
    description: 'Asistencia y defensa en todas las fases del proceso penal para proteger tus derechos y tu libertad.',
    icon: Gavel,
    features: [
      'Defensa en procesos penales',
      'Delitos económicos y financieros',
      'Delitos contra la seguridad vial',
      'Defensa ante la Audiencia Nacional',
      'Recursos de apelación y casación'
    ]
  },
  {
    title: 'Derecho Civil',
    description: 'Soluciones a conflictos entre particulares sobre contratos, propiedades, herencias y obligaciones.',
    icon: Scale,
    features: [
      'Reclamaciones por incumplimiento de contrato',
      'Herencias y testamentos',
      'Responsabilidad civil y reclamaciones de daños',
      'Propiedad horizontal y arrendamientos',
      'Protección de consumidores'
    ]
  },
  {
    title: 'Derecho Laboral',
    description: 'Defendemos tanto a trabajadores como a empresas en casos de despidos, reclamaciones y negociaciones.',
    icon: Users,
    features: [
      'Despidos improcedentes y objetivos',
      'Reclamaciones de cantidad',
      'Modificación de condiciones laborales',
      'Conflictos colectivos',
      'Negociación de convenios y ERE'
    ]
  },
  {
    title: 'Derecho de Familia',
    description: 'Te acompañamos en procesos sensibles como divorcios, custodias y pensiones alimenticias con empatía y rigor.',
    icon: HeartHandshake,
    features: [
      'Divorcios de mutuo acuerdo y contenciosos',
      'Custodia de menores y régimen de visitas',
      'Pensiones compensatorias y de alimentos',
      'Liquidación de régimen económico matrimonial',
      'Modificación de medidas'
    ]
  },
  {
    title: 'Derecho Comercial',
    description: 'Asesoramiento integral para empresas en la creación de sociedades, contratos mercantiles y litigios.',
    icon: Briefcase,
    features: [
      'Constitución y disolución de sociedades',
      'Contratos mercantiles',
      'Derecho de la competencia',
      'Propiedad industrial e intelectual',
      'Fusiones y adquisiciones'
    ]
  },
  {
    title: 'Consultoría Legal',
    description: 'Asesoramiento preventivo y estratégico para evitar futuros conflictos legales a nivel personal o empresarial.',
    icon: FileSearch,
    features: [
      'Asesoramiento legal continuado',
      'Due diligence legal',
      'Auditorías de cumplimiento normativo',
      'Gestión de riesgos legales',
      'Redacción y revisión de contratos'
    ]
  },
];

const additionalServices = [
  {
    title: 'Derecho Inmobiliario',
    description: 'Asesoramiento en compraventa de inmuebles, arrendamientos y gestiones urbanísticas.',
    icon: Building,
  },
  {
    title: 'Derecho Administrativo',
    description: 'Representación ante la Administración Pública y recursos contencioso-administrativos.',
    icon: Landmark,
  },
  {
    title: 'Derecho Tributario',
    description: 'Planificación fiscal, recursos ante la Agencia Tributaria y defensa en procedimientos sancionadores.',
    icon: Banknote,
  },
];

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

const Servicios = () => {
  return (
    <RootLayout>
      <div className="bg-muted py-20 mt-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold font-['Raleway'] mb-4 text-gradient">
              Nuestros Servicios
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Ofrecemos asesoramiento legal especializado en diversas áreas del derecho, con un enfoque personalizado para cada cliente.
            </p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16">
        <motion.div
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16"
        >
          {mainServices.map((service, index) => (
            <motion.div key={index} variants={item}>
              <div className="service-card h-full flex flex-col">
                <div className="flex items-center mb-4">
                  <div className="p-3 rounded-full bg-primary/10 mr-4">
                    <service.icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold font-['Raleway']">{service.title}</h3>
                </div>
                <p className="text-muted-foreground mb-6">{service.description}</p>
                
                <div className="mt-auto">
                  <h4 className="font-medium text-primary mb-3">Servicios incluidos:</h4>
                  <ul className="space-y-2">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-accent mt-1 flex-shrink-0" />
                        <span className="text-sm text-foreground/90">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>

        <div className="my-16">
          <h2 className="text-2xl md:text-3xl font-semibold font-['Raleway'] mb-8 text-center">
            Servicios Adicionales
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {additionalServices.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-card border border-border p-6 rounded-lg shadow-sm"
              >
                <div className="flex items-center mb-4">
                  <div className="p-3 rounded-full bg-primary/10 mr-4">
                    <service.icon className="w-5 h-5 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold font-['Raleway']">{service.title}</h3>
                </div>
                <p className="text-muted-foreground">{service.description}</p>
              </motion.div>
            ))}
          </div>
        </div>

        <div className="bg-primary text-primary-foreground rounded-lg p-8 md:p-12 mt-16 text-center">
          <h2 className="text-2xl md:text-3xl font-semibold font-['Raleway'] mb-4">
            ¿Necesita asesoramiento legal?
          </h2>
          <p className="text-primary-foreground/90 max-w-2xl mx-auto mb-8">
            Nuestro equipo de abogados especializados está listo para ayudarle con su caso. 
            Contáctenos hoy para una primera consulta sin compromiso.
          </p>
          <AppointmentDialog>
            <Button className="bg-accent hover:bg-accent/90 text-accent-foreground text-lg px-8 py-6 shadow-lg hover:shadow-accent/20">
              Solicitar Consulta
            </Button>
          </AppointmentDialog>
        </div>
      </div>
    </RootLayout>
  );
};

export default Servicios;