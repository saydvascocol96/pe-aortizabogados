import RootLayout from '@/components/layout/RootLayout';
import { motion } from 'framer-motion';
import { CheckCircle, Mail, Phone } from 'lucide-react';

const teamMembers = [
  {
    name: "ESTIVEN VASCONEZ",
    role: "Abogado",
    specialization: "Derecho Laboral",
    description: "Especialista en casos complejos de derecho laboral y corporativo.",
    image: "/media/estiven-vasconez.jpg",
    email: "estiven@penaortizabogados.com",
    phone: "+57 3178431546",
    education: "UNIVERSIDAD CESMAG"
  },
  {
    name: "DAYANA VASCONEZ",
    role: "Abogada",
    specialization: "Derecho de Familia",
    description: "Experta en derecho de familia, ha gestionado con éxito cientos de casos de divorcios, custodias y regímenes económicos matrimoniales.",
    image: "/media/estiven-vasconez-abogado.jpg",
    email: "dayana@penaortizabogados.com",
    phone: "+57 3178431546",
    education: "UNIVERSIDAD CESMAG"
  },
  {
    name: "GINNA VASCONEZ",
    role: "Abogada",
    specialization: "Derecho Civil",
    description: "Representa tanto a empresas como a particulares en todo tipo de asuntos civiles.",
    image: "/media/estiven-vasconez.jpg",
    email: "ginna@penaortizabogados.com",
    phone: "+57 3178431546",
    education: "UNIVERSIDAD CESMAG"
  }
];

const Equipo = () => {
  return (
    <RootLayout>
      <div className="bg-muted py-20 mt-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold font-['Raleway'] mb-4 text-gradient">
              Nuestro Equipo
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Profesionales comprometidos con la excelencia legal y el servicio al cliente.
            </p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {teamMembers.map((member, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="bg-card border border-border rounded-lg shadow-md overflow-hidden flex flex-col md:flex-row"
            >
              <div className="md:w-1/3">
                <img 
                  src={member.image} 
                  alt={member.name} 
                  className="w-full h-64 md:h-full object-cover"
                />
              </div>
              <div className="p-6 md:w-2/3">
                <h2 className="text-2xl font-semibold font-['Raleway'] mb-1">{member.name}</h2>
                <p className="text-primary font-medium mb-2">{member.role}</p>
                <p className="text-accent mb-4 font-medium">{member.specialization}</p>
                <p className="text-muted-foreground mb-4">{member.description}</p>
                
                <div className="mt-4 mb-4">
                  <h3 className="font-medium mb-1">Educación</h3>
                  <p className="text-muted-foreground">{member.education}</p>
                </div>
                
                <div className="flex flex-col gap-2 mt-4">
                  <div className="flex items-center gap-2">
                    <Mail size={16} className="text-primary" />
                    <span className="text-muted-foreground">{member.email}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone size={16} className="text-primary" />
                    <span className="text-muted-foreground">{member.phone}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-16 bg-muted p-8 rounded-lg">
          <h2 className="text-2xl font-semibold font-['Raleway'] mb-6">¿Por qué elegir a nuestro equipo?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex items-start gap-3">
              <CheckCircle className="text-primary flex-shrink-0 mt-1" size={20} />
              <div>
                <h3 className="font-medium">Experiencia Demostrada</h3>
                <p className="text-muted-foreground">Nuestros profesionales cuentan con amplia experiencia en sus respectivas áreas de especialización.</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="text-primary flex-shrink-0 mt-1" size={20} />
              <div>
                <h3 className="font-medium">Atención Personalizada</h3>
                <p className="text-muted-foreground">Cada cliente recibe atención directa de nuestros abogados, sin intermediarios.</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="text-primary flex-shrink-0 mt-1" size={20} />
              <div>
                <h3 className="font-medium">Formación Continua</h3>
                <p className="text-muted-foreground">Nos mantenemos constantemente actualizados sobre las últimas novedades legislativas y jurisprudenciales.</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="text-primary flex-shrink-0 mt-1" size={20} />
              <div>
                <h3 className="font-medium">Enfoque Multidisciplinar</h3>
                <p className="text-muted-foreground">Trabajamos en equipo para ofrecer soluciones integrales a problemas jurídicos complejos.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </RootLayout>
  );
};

export default Equipo;