import { useState } from 'react';
import RootLayout from '@/components/layout/RootLayout';
import BlogCard from '@/components/blog/BlogCard';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search } from 'lucide-react';

// Sample blog data
const blogArticles = [
  {
    id: 'registro-horario-laboral',
    title: '5 Claves sobre el nuevo registro horario en el trabajo',
    excerpt: 'El registro de jornada laboral es obligatorio en España desde mayo de 2019. Conoce las claves principales para cumplir con esta normativa y evitar sanciones para tu empresa.',
    image: 'https://storage.googleapis.com/fenado-ai-farm-public/generated/d15d24e8-2083-4093-8abd-2d4364077195.webp',
    date: '12 agosto, 2025',
    readTime: '5 min lectura',
    category: 'laboral'
  },
  {
    id: 'notificacion-judicial',
    title: '¿Qué hacer si recibes una notificación del juzgado?',
    excerpt: 'Recibir una notificación judicial puede ser una experiencia estresante. Te explicamos los pasos a seguir y cómo actuar correctamente para proteger tus derechos.',
    image: 'https://storage.googleapis.com/fenado-ai-farm-public/generated/8e54e379-a992-41b2-87c8-056fe5ea8019.webp',
    date: '5 agosto, 2025',
    readTime: '7 min lectura',
    category: 'civil'
  },
  {
    id: 'herencias-testamentos',
    title: 'Herencias y testamentos: cómo planificar el futuro',
    excerpt: 'La planificación sucesoria es fundamental para garantizar que tus bienes se distribuyan según tus deseos. Descubre las opciones legales disponibles y los beneficios fiscales.',
    image: 'https://storage.googleapis.com/fenado-ai-farm-public/generated/9c0b1b18-096b-401d-952f-d5b672b35649.webp',
    date: '29 julio, 2025',
    readTime: '8 min lectura',
    category: 'familia'
  },
  {
    id: 'derechos-consumidor',
    title: 'Derechos del consumidor en compras online: lo que debes saber',
    excerpt: 'Las compras por internet tienen particularidades legales que todo consumidor debería conocer. Te explicamos tus derechos y cómo ejercerlos si surge algún problema.',
    image: 'https://storage.googleapis.com/fenado-ai-farm-public/generated/d15d24e8-2083-4093-8abd-2d4364077195.webp',
    date: '22 julio, 2025',
    readTime: '6 min lectura',
    category: 'civil'
  },
  {
    id: 'despido-improcedente',
    title: 'Despido improcedente: cómo reconocerlo y qué hacer',
    excerpt: 'El despido improcedente ocurre cuando no se cumplen los requisitos legales para finalizar una relación laboral. Aprende a identificarlo y conoce los pasos a seguir.',
    image: 'https://storage.googleapis.com/fenado-ai-farm-public/generated/d15d24e8-2083-4093-8abd-2d4364077195.webp',
    date: '15 julio, 2025',
    readTime: '7 min lectura',
    category: 'laboral'
  },
  {
    id: 'sociedades-limitadas',
    title: 'Guía para crear una Sociedad Limitada en 2025',
    excerpt: 'La creación de una SL requiere seguir varios pasos legales. Esta guía te explica el proceso completo, desde la elección del nombre hasta la inscripción en el Registro Mercantil.',
    image: 'https://storage.googleapis.com/fenado-ai-farm-public/generated/d15d24e8-2083-4093-8abd-2d4364077195.webp',
    date: '8 julio, 2025',
    readTime: '10 min lectura',
    category: 'comercial'
  }
];

// Categories for filtering
const categories = [
  { id: 'all', name: 'Todos' },
  { id: 'civil', name: 'Derecho Civil' },
  { id: 'laboral', name: 'Derecho Laboral' },
  { id: 'familia', name: 'Derecho de Familia' },
  { id: 'comercial', name: 'Derecho Comercial' },
  { id: 'penal', name: 'Derecho Penal' }
];

const Blog = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');

  // Filter articles based on search term and category
  const filteredArticles = blogArticles.filter(article => {
    const matchesSearch = article.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         article.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = activeCategory === 'all' || article.category === activeCategory;
    
    return matchesSearch && matchesCategory;
  });

  return (
    <RootLayout>
      <div className="bg-muted py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold font-['Raleway'] mb-4 text-gradient">
              Nuestro Blog Jurídico
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Análisis, noticias y consejos legales de nuestros expertos.
            </p>
          </div>

          {/* Search and filters */}
          <div className="max-w-4xl mx-auto mb-12">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-grow">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" size={18} />
                <Input
                  type="text"
                  placeholder="Buscar artículos..."
                  className="pl-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>

            <div className="mt-6 flex flex-wrap gap-2">
              {categories.map(category => (
                <Button
                  key={category.id}
                  variant={activeCategory === category.id ? "default" : "outline"}
                  className={activeCategory === category.id ? "legal-btn" : "legal-btn-outline"}
                  onClick={() => setActiveCategory(category.id)}
                >
                  {category.name}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16">
        {filteredArticles.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredArticles.map((article, index) => (
              <BlogCard
                key={article.id}
                id={article.id}
                title={article.title}
                excerpt={article.excerpt}
                image={article.image}
                date={article.date}
                readTime={article.readTime}
                index={index}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-xl text-muted-foreground">No se encontraron artículos que coincidan con su búsqueda.</p>
            <Button 
              className="legal-btn mt-4"
              onClick={() => {
                setSearchTerm('');
                setActiveCategory('all');
              }}
            >
              Ver todos los artículos
            </Button>
          </div>
        )}
      </div>
    </RootLayout>
  );
};

export default Blog;