import RootLayout from '@/components/layout/RootLayout';

const Cookies = () => {
  return (
    <RootLayout>
      <div className="bg-muted py-20">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold font-['Raleway'] text-center mb-6 text-gradient">
            Política de Cookies
          </h1>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto prose prose-lg">
          <h2>¿Qué son las cookies?</h2>
          <p>
            Una cookie es un pequeño archivo de texto que un sitio web coloca en su ordenador, teléfono o cualquier otro dispositivo, con información sobre su navegación en dicho sitio. Las cookies son necesarias para facilitar la navegación y hacerla más amigable, y no dañan su ordenador.
          </p>
          <p>
            Aunque en esta política se utiliza el término general de "cookie", pues es el principal método de almacenamiento de información que utiliza este sitio web, también se utiliza el espacio de "Almacenamiento local" del navegador para los mismos propósitos que las cookies. En este sentido, toda la información incluida en esta sección es aplicable igualmente a este "Almacenamiento local".
          </p>

          <h2>Tipos de cookies</h2>
          <p>
            Existen diferentes tipos de cookies en función de diversos criterios:
          </p>

          <h3>Según la entidad que las gestione</h3>
          <ul>
            <li><strong>Cookies propias:</strong> Son aquellas que se envían al equipo terminal del usuario desde un equipo o dominio gestionado por el propio editor y desde el que se presta el servicio solicitado por el usuario.</li>
            <li><strong>Cookies de terceros:</strong> Son aquellas que se envían al equipo terminal del usuario desde un equipo o dominio que no es gestionado por el editor, sino por otra entidad que trata los datos obtenidos través de las cookies.</li>
          </ul>

          <h3>Según el plazo de tiempo que permanecen activadas</h3>
          <ul>
            <li><strong>Cookies de sesión:</strong> Son cookies temporales que permanecen en el archivo de cookies de su navegador hasta que abandone la página web, por lo que ninguna queda registrada en el disco duro del usuario.</li>
            <li><strong>Cookies persistentes:</strong> Son almacenadas en el disco duro y nuestra web las lee cada vez que usted realiza una nueva visita. Una cookie permanente posee una fecha de expiración determinada. La cookie dejará de funcionar después de esa fecha.</li>
          </ul>

          <h3>Según su finalidad</h3>
          <ul>
            <li><strong>Cookies técnicas:</strong> Son aquellas que permiten al usuario la navegación a través de una página web, plataforma o aplicación y la utilización de las diferentes opciones o servicios que en ella existan.</li>
            <li><strong>Cookies de personalización:</strong> Son aquellas que permiten al usuario acceder al servicio con algunas características de carácter general predefinidas en función de una serie de criterios en el terminal del usuario (por ejemplo, el idioma o el tipo de navegador).</li>
            <li><strong>Cookies de análisis:</strong> Son aquellas que permiten al responsable de las mismas, el seguimiento y análisis del comportamiento de los usuarios de los sitios web a los que están vinculadas.</li>
            <li><strong>Cookies publicitarias:</strong> Son aquellas que permiten la gestión, de la forma más eficaz posible, de los espacios publicitarios que, en su caso, el editor haya incluido en una página web.</li>
          </ul>

          <h2>Cookies utilizadas en nuestra web</h2>
          <p>
            Nuestra página web utiliza los siguientes tipos de cookies:
          </p>
          <ul>
            <li><strong>Cookies técnicas:</strong> Permiten al usuario navegar por la web y utilizar funcionalidades básicas.</li>
            <li><strong>Cookies de análisis:</strong> Nos permiten analizar el comportamiento de los usuarios de forma anónima para mejorar nuestros servicios.</li>
            <li><strong>Cookies de personalización:</strong> Permiten recordar preferencias del usuario como el idioma o la configuración visual.</li>
          </ul>

          <h2>Cómo gestionar las cookies</h2>
          <p>
            Puede permitir, bloquear o eliminar las cookies instaladas en su equipo mediante la configuración de las opciones del navegador instalado en su ordenador. A continuación le ofrecemos enlaces donde encontrará información sobre cómo puede activar sus preferencias en los principales navegadores:
          </p>
          <ul>
            <li><a href="https://support.google.com/chrome/answer/95647" target="_blank" rel="noopener noreferrer" className="legal-link">Google Chrome</a></li>
            <li><a href="https://support.mozilla.org/es/kb/habilitar-y-deshabilitar-cookies-sitios-web-rastrear-preferencias" target="_blank" rel="noopener noreferrer" className="legal-link">Mozilla Firefox</a></li>
            <li><a href="https://support.apple.com/es-es/guide/safari/sfri11471/mac" target="_blank" rel="noopener noreferrer" className="legal-link">Safari</a></li>
            <li><a href="https://support.microsoft.com/es-es/microsoft-edge/eliminar-las-cookies-en-microsoft-edge-63947406-40ac-c3b8-57b9-2a946a29ae09" target="_blank" rel="noopener noreferrer" className="legal-link">Microsoft Edge</a></li>
          </ul>

          <h2>Actualizaciones y cambios en la política de cookies</h2>
          <p>
            Lex Veritas Abogados S.L.P. puede modificar esta Política de Cookies en función de exigencias legislativas, reglamentarias, o con la finalidad de adaptar dicha política a las instrucciones dictadas por la Agencia Española de Protección de Datos, por ello se aconseja a los usuarios que la visiten periódicamente.
          </p>

          <p className="text-sm text-muted-foreground mt-8">
            Última actualización: Agosto de 2025
          </p>
        </div>
      </div>
    </RootLayout>
  );
};

export default Cookies;