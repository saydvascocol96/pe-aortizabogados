import { motion } from 'framer-motion';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';
import ContactForm from '@/components/ContactForm';

const ContactSection = () => {
  return (
    <section id="contacto" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="section-title text-gradient">
            Hablemos de su caso
          </h2>
          <p className="section-description mx-auto">
            Complete el formulario para una primera consulta sin compromiso. Su información es confidencial.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            viewport={{ once: true }}
            className="bg-card border border-border rounded-lg shadow-md p-6 md:p-8"
          >
            <h3 className="text-2xl font-semibold font-['Raleway'] mb-6">
              Envíenos un mensaje
            </h3>
            <ContactForm />
          </motion.div>

          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            {/* Map */}
            <div className="rounded-lg overflow-hidden shadow-md border border-border h-64 bg-muted">
              <div className="w-full h-full bg-muted flex items-center justify-center">
                <div className="text-center p-6">
                  <MapPin className="w-12 h-12 text-primary mx-auto mb-4" />
                  <p className="text-muted-foreground">Mapa interactivo (versión prototipo)</p>
                </div>
              </div>
            </div>

            {/* Contact details */}
            <div className="bg-card border border-border rounded-lg shadow-md p-6">
              <h3 className="text-2xl font-semibold font-['Raleway'] mb-6">
                Información de contacto
              </h3>

              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <MapPin className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-medium">Dirección</h4>
                    <p className="text-muted-foreground">Cr 21 #14 21 - Las Américas</p>
                    <p className="text-muted-foreground">Pasto, Colombia</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <Phone className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-medium">Teléfono</h4>
                    <p className="text-muted-foreground">+57 3178431546</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <Mail className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-medium">Correo electrónico</h4>
                    <p className="text-muted-foreground">penaortizabogados@gmail.com</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <Clock className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-medium">Horario</h4>
                    <p className="text-muted-foreground">Lunes a Viernes: 9:00 - 18:00</p>
                    <p className="text-muted-foreground">Sábados: Cerrado</p>
                    <p className="text-muted-foreground">Domingos: Cerrado</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;