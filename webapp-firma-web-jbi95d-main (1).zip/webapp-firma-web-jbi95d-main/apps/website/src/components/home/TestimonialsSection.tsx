import { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight, Quote } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';

const testimonials = [
  {
    quote: "Desde el primer momento me sentí escuchado y respaldado. El equipo de Lex Veritas fue increíblemente profesional y eficiente. ¡Los recomiendo totalmente!",
    author: "Carlos G.",
    role: "Cliente de Derecho Laboral",
    avatar: "/media/firma-web-visual.jpg"
  },
  {
    quote: "Afrontar un proceso de divorcio fue muy duro, pero ellos me guiaron con una empatía y una claridad que agradecí enormemente. Me dieron la tranquilidad que necesitaba.",
    author: "María L.",
    role: "Cliente de Derecho de Familia",
    avatar: "/media/firma-web-page.jpg"
  },
  {
    quote: "Necesitábamos un asesoramiento mercantil rápido y preciso para nuestra startup. Su conocimiento y agilidad fueron clave para nosotros. Excelentes profesionales.",
    author: "Proyectos Tech S.L.",
    role: "Cliente de Derecho Comercial",
    avatar: "/media/firma-web-interface.jpg"
  }
];

const TestimonialsSection = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextTestimonial = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section id="testimonios" className="py-20 bg-background relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 right-0 w-80 h-80 bg-accent/5 rounded-full blur-3xl"></div>
      
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="section-title text-gradient">
            Lo que dicen nuestros clientes
          </h2>
          <p className="section-description mx-auto">
            El compromiso con nuestros clientes se refleja en su satisfacción y confianza.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="relative">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -100 }}
              transition={{ duration: 0.5 }}
              className="testimonial-card"
            >
              <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
                <div className="flex-shrink-0">
                  <Avatar className="w-24 h-24 border-4 border-border shadow-lg">
                    <AvatarImage src={testimonials[currentIndex].avatar} alt={testimonials[currentIndex].author} />
                    <AvatarFallback className="bg-primary text-primary-foreground text-xl">
                      {testimonials[currentIndex].author.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                </div>

                <div className="flex-grow">
                  <Quote className="text-accent/40 mb-2" size={40} />
                  <p className="text-foreground/90 text-lg italic mb-6">
                    "{testimonials[currentIndex].quote}"
                  </p>
                  <div>
                    <p className="font-semibold font-['Raleway'] text-foreground">
                      {testimonials[currentIndex].author}
                    </p>
                    <p className="text-muted-foreground text-sm">
                      {testimonials[currentIndex].role}
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Navigation buttons */}
            <div className="flex justify-center mt-8 gap-4">
              <Button
                variant="outline"
                size="icon"
                onClick={prevTestimonial}
                className="rounded-full border-primary hover:bg-primary/10"
              >
                <ChevronLeft className="h-5 w-5" />
              </Button>
              <div className="flex items-center gap-2">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentIndex(index)}
                    className={`w-3 h-3 rounded-full transition-all duration-300 ${
                      index === currentIndex ? "bg-primary scale-125" : "bg-primary/30"
                    }`}
                    aria-label={`Go to testimonial ${index + 1}`}
                  ></button>
                ))}
              </div>
              <Button
                variant="outline"
                size="icon"
                onClick={nextTestimonial}
                className="rounded-full border-primary hover:bg-primary/10"
              >
                <ChevronRight className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;