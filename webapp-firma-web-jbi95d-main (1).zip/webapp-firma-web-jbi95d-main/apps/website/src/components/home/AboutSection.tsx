import { motion } from 'framer-motion';
import { CheckCircle } from 'lucide-react';

const values = [
  { title: 'Integridad', description: 'Actuamos con honestidad y ética en todos nuestros servicios.' },
  { title: 'Compromiso', description: 'Nos dedicamos plenamente a cada caso con la máxima atención.' },
  { title: 'Excelencia', description: 'Buscamos constantemente la perfección en nuestro trabajo.' },
  { title: 'Cercanía', description: 'Mantenemos una comunicación clara y accesible con nuestros clientes.' },
];

const AboutSection = () => {
  return (
    <section id="nosotros" className="py-20 bg-muted">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="section-title text-gradient">
            Un equipo comprometido con su causa
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Image column */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="rounded-lg overflow-hidden shadow-xl">
              <img
                src="/media/equipo-abogados.jpg"
                alt="Equipo de PEÑA&ORTIZ ABOGADOS"
                className="w-full h-auto"
              />
            </div>
            <div className="absolute -bottom-5 -right-5 bg-accent p-4 rounded-lg shadow-lg hidden lg:block">
              <p className="text-accent-foreground font-semibold">Abogados de confianza</p>
            </div>
          </motion.div>

          {/* Content column */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            <div>
              <h3 className="section-subtitle">Nuestra Historia</h3>
              <p className="text-foreground/90 mb-6">
                PEÑA&ORTIZ ABOGADOS fue fundado con la visión de crear un bufete que combinara la excelencia legal con un trato humano y cercano. A lo largo de los años, hemos crecido gracias a la confianza de nuestros clientes, manteniéndonos fieles a nuestros valores fundamentales: integridad, dedicación y la búsqueda incansable de la justicia.
              </p>
            </div>

            <div>
              <h3 className="section-subtitle">Nuestros Valores</h3>
              <p className="text-foreground/90 mb-6">
                Creemos en la transparencia, la comunicación constante y la defensa estratégica de los intereses de quienes confían en nosotros.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
                {values.map((value, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className="flex items-start space-x-3"
                  >
                    <CheckCircle className="text-accent flex-shrink-0 mt-1" size={20} />
                    <div>
                      <h4 className="font-semibold font-['Raleway']">{value.title}</h4>
                      <p className="text-sm text-muted-foreground">{value.description}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;