import { motion } from 'framer-motion';
import { Scale } from 'lucide-react';
import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import ContactForm from '@/components/ContactForm';

const CtaSection = () => {
  return (
    <section className="py-20 bg-primary relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-full h-full">
        <div className="absolute top-10 left-10 w-40 h-40 border-4 border-primary-foreground/10 rounded-full"></div>
        <div className="absolute bottom-40 right-10 w-20 h-20 border-4 border-primary-foreground/10 rounded-full"></div>
        <div className="absolute top-40 right-40 w-60 h-60 border-4 border-primary-foreground/10 rounded-full"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto text-center text-primary-foreground"
        >
          <Scale className="w-16 h-16 text-accent mx-auto mb-6" />
          
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold font-['Raleway'] mb-6">
            ¿Necesitas asesoramiento legal?
          </h2>
          
          <p className="text-xl text-primary-foreground/90 mb-8">
            Nuestro equipo de profesionales está listo para ayudarte. 
            Contáctanos hoy mismo para una consulta personalizada.
          </p>

          <Dialog>
            <DialogTrigger asChild>
              <Button className="bg-accent hover:bg-accent/90 text-accent-foreground text-lg px-8 py-6 shadow-lg hover:shadow-accent/20">
                Contactar Ahora
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <div className="space-y-4">
                <h2 className="text-2xl font-semibold text-foreground">Contáctanos</h2>
                <p className="text-muted-foreground">Complete el formulario para una primera consulta sin compromiso. Su información es confidencial.</p>
                <ContactForm />
              </div>
            </DialogContent>
          </Dialog>
        </motion.div>
      </div>
    </section>
  );
};

export default CtaSection;