import { motion } from 'framer-motion';
import { Gavel, Scale, Briefcase, Users, HeartHandshake, FileSearch } from 'lucide-react';

const services = [
  {
    title: 'Derecho Penal',
    description: 'Asistencia y defensa en todas las fases del proceso penal para proteger tus derechos y tu libertad.',
    icon: Gavel,
  },
  {
    title: 'Derecho Civil',
    description: 'Soluciones a conflictos entre particulares sobre contratos, propiedades, herencias y obligaciones.',
    icon: Scale,
  },
  {
    title: 'Derecho Laboral',
    description: 'Defendemos tanto a trabajadores como a empresas en casos de despidos, reclamaciones y negociaciones.',
    icon: Users,
  },
  {
    title: 'Derecho de Familia',
    description: 'Te acompañamos en procesos sensibles como divorcios, custodias y pensiones alimenticias con empatía y rigor.',
    icon: HeartHandshake,
  },
  {
    title: 'Derecho Comercial',
    description: 'Asesoramiento integral para empresas en la creación de sociedades, contratos mercantiles y litigios.',
    icon: Briefcase,
  },
  {
    title: 'Consultoría Legal',
    description: 'Asesoramiento preventivo y estratégico para evitar futuros conflictos legales a nivel personal o empresarial.',
    icon: FileSearch,
  },
];

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

const ServicesSection = () => {
  return (
    <section id="servicios" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="section-title text-gradient">
            Áreas de Práctica
          </h2>
          <p className="section-description mx-auto">
            Ofrecemos asesoramiento legal especializado en diversas áreas del derecho, con un enfoque personalizado para cada cliente.
          </p>
        </div>

        <motion.div
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-50px" }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {services.map((service, index) => (
            <motion.div key={index} variants={item}>
              <div className="service-card h-full">
                <div className="flex items-center mb-4">
                  <div className="p-3 rounded-full bg-primary/10 mr-4">
                    <service.icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold font-['Raleway']">{service.title}</h3>
                </div>
                <p className="text-muted-foreground">{service.description}</p>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default ServicesSection;