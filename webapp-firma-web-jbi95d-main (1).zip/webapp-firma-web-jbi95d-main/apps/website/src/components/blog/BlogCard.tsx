import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CalendarIcon, Clock } from 'lucide-react';

interface BlogCardProps {
  id: string;
  title: string;
  excerpt: string;
  image: string;
  date: string;
  readTime: string;
  index?: number;
}

const BlogCard = ({ id, title, excerpt, image, date, readTime, index = 0 }: BlogCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      viewport={{ once: true }}
    >
      <Card className="h-full overflow-hidden group hover:shadow-lg transition-all duration-300">
        <div className="relative overflow-hidden h-48">
          <img
            src={image}
            alt={title}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
        </div>
        
        <CardContent className="pt-6">
          <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
            <span className="flex items-center gap-1">
              <CalendarIcon className="w-4 h-4" />
              {date}
            </span>
            <span className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              {readTime}
            </span>
          </div>
          
          <h3 className="text-xl font-semibold font-['Raleway'] mb-3">
            {title}
          </h3>
          
          <p className="text-muted-foreground mb-4 line-clamp-3">
            {excerpt}
          </p>
        </CardContent>
        
        <CardFooter>
          <Button asChild className="legal-btn-outline w-full">
            <Link to={`/blog/${id}`}>Leer más</Link>
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default BlogCard;