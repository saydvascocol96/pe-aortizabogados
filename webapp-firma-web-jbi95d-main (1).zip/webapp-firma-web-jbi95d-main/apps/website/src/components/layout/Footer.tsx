import { Link } from 'react-router-dom';
import { Facebook, Linkedin, Twitter } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Column 1 - Logo & Tagline */}
          <div className="space-y-4">
            <Link to="/" className="flex items-center">
              <img 
                src="https://storage.googleapis.com/fenado-ai-farm-public/generated/eb977d2e-3dd7-4894-bf3f-6da8808cb7fd.webp" 
                alt="PEÑA&ORTIZ ABOGADOS" 
                className="h-12 w-auto"
              />
            </Link>
            <h3 className="text-xl font-semibold mt-4 font-['Raleway']">PEÑA&ORTIZ ABOGADOS</h3>
            <p className="text-primary-foreground/80">Defendiendo sus derechos con compromiso y profesionalismo.</p>
          </div>

          {/* Column 2 - Contact Info */}
          <div className="space-y-4">
            <h3 className="text-xl font-semibold font-['Raleway']">Contacto</h3>
            <address className="not-italic space-y-2 text-primary-foreground/80">
              <p>Cr 21 #14 21 - Las Américas</p>
              <p>Pasto, Colombia</p>
              <p>Teléfono: +57 3178431546</p>
              <p>Email: penaortizabogados@gmail.com</p>
            </address>
          </div>

          {/* Column 3 - Links & Social */}
          <div className="space-y-4">
            <h3 className="text-xl font-semibold font-['Raleway']">Enlaces</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/aviso-legal" className="text-primary-foreground/80 hover:text-primary-foreground hover:underline transition-colors">
                  Aviso Legal
                </Link>
              </li>
              <li>
                <Link to="/privacidad" className="text-primary-foreground/80 hover:text-primary-foreground hover:underline transition-colors">
                  Política de Privacidad
                </Link>
              </li>
              <li>
                <Link to="/cookies" className="text-primary-foreground/80 hover:text-primary-foreground hover:underline transition-colors">
                  Política de Cookies
                </Link>
              </li>
            </ul>

            <div className="pt-4">
              <h4 className="text-lg font-semibold mb-2 font-['Raleway']">Síguenos</h4>
              <div className="flex space-x-4">
                <a href="#" className="text-primary-foreground/80 hover:text-accent transition-colors" aria-label="LinkedIn">
                  <Linkedin size={24} />
                </a>
                <a href="#" className="text-primary-foreground/80 hover:text-accent transition-colors" aria-label="Twitter">
                  <Twitter size={24} />
                </a>
                <a href="#" className="text-primary-foreground/80 hover:text-accent transition-colors" aria-label="Facebook">
                  <Facebook size={24} />
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-primary-foreground/20 mt-10 pt-6 text-center text-primary-foreground/70 text-sm">
          <p>© {currentYear} PEÑA&ORTIZ ABOGADOS. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;