import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Menu, X } from 'lucide-react';
import AppointmentDialog from '@/components/dialogs/AppointmentDialog';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    setMobileMenuOpen(false);
    
    // If we're on the home page, scroll to the section
    if (location.pathname === '/') {
      const section = document.getElementById(sectionId);
      if (section) {
        section.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      // If we're on another page, navigate to home and then scroll
      window.location.href = `/#${sectionId}`;
    }
  };

  return (
    <header className={`fixed w-full top-0 z-40 transition-all duration-300 ${
      isScrolled || location.pathname !== '/' 
        ? 'bg-card shadow-md backdrop-blur-sm' 
        : 'bg-transparent'
    }`}>
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center">
          <img 
            src="https://storage.googleapis.com/fenado-ai-farm-public/generated/eb977d2e-3dd7-4894-bf3f-6da8808cb7fd.webp" 
            alt="PEÑA&ORTIZ ABOGADOS" 
            className="h-10 w-auto"
          />
          <span className="ml-3 text-lg font-semibold text-foreground font-['Raleway'] hidden md:block">
            PEÑA&ORTIZ <span className="text-primary">ABOGADOS</span>
          </span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <Link 
            to="/"
            className="text-foreground hover:text-primary transition-colors relative group"
          >
            Inicio
            <span className="absolute inset-x-0 bottom-0 h-0.5 bg-accent transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-center"></span>
          </Link>
          <Link 
            to="/servicios"
            className="text-foreground hover:text-primary transition-colors relative group"
          >
            Servicios
            <span className="absolute inset-x-0 bottom-0 h-0.5 bg-accent transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-center"></span>
          </Link>
          <Link 
            to="/equipo"
            className="text-foreground hover:text-primary transition-colors relative group"
          >
            Nuestro Equipo
            <span className="absolute inset-x-0 bottom-0 h-0.5 bg-accent transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-center"></span>
          </Link>
          <Link 
            to="/testimonios"
            className="text-foreground hover:text-primary transition-colors relative group"
          >
            Testimonios
            <span className="absolute inset-x-0 bottom-0 h-0.5 bg-accent transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-center"></span>
          </Link>
          <Link 
            to="/blog" 
            className="text-foreground hover:text-primary transition-colors relative group"
          >
            Blog
            <span className="absolute inset-x-0 bottom-0 h-0.5 bg-accent transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-center"></span>
          </Link>
          <Link 
            to="/contacto"
            className="text-foreground hover:text-primary transition-colors relative group"
          >
            Contacto
            <span className="absolute inset-x-0 bottom-0 h-0.5 bg-accent transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-center"></span>
          </Link>
        </nav>

        {/* CTA Button */}
        <AppointmentDialog>
          <Button className="legal-btn hidden md:flex">
            Agendar Cita
          </Button>
        </AppointmentDialog>

        {/* Mobile Menu Button */}
        <button 
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden text-foreground p-2 rounded-md hover:bg-muted transition-colors"
        >
          {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-card shadow-lg border-t border-border">
          <div className="container mx-auto px-4 py-4 space-y-4">
            <Link 
              to="/" 
              className="block w-full text-left py-2 text-foreground hover:text-primary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              Inicio
            </Link>
            <Link 
              to="/servicios" 
              className="block w-full text-left py-2 text-foreground hover:text-primary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              Servicios
            </Link>
            <Link 
              to="/equipo" 
              className="block w-full text-left py-2 text-foreground hover:text-primary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              Nuestro Equipo
            </Link>
            <Link 
              to="/testimonios" 
              className="block w-full text-left py-2 text-foreground hover:text-primary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              Testimonios
            </Link>
            <Link 
              to="/blog" 
              className="block w-full text-left py-2 text-foreground hover:text-primary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              Blog
            </Link>
            <Link 
              to="/contacto" 
              className="block w-full text-left py-2 text-foreground hover:text-primary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              Contacto
            </Link>
            <AppointmentDialog>
              <Button className="legal-btn w-full mt-2">
                Agendar Cita
              </Button>
            </AppointmentDialog>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;