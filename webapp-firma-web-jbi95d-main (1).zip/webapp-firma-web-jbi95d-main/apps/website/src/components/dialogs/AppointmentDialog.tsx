import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import ContactForm from '@/components/ContactForm';
import { ReactNode } from 'react';

interface AppointmentDialogProps {
  children: ReactNode;
  buttonText?: string;
}

const AppointmentDialog = ({ children, buttonText = "Agendar Cita" }: AppointmentDialogProps) => {
  return (
    <Dialog>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <div className="space-y-4">
          <h2 className="text-2xl font-semibold text-foreground">Agende su Cita</h2>
          <p className="text-muted-foreground">Complete el formulario para una primera consulta sin compromiso. Su información es confidencial.</p>
          <ContactForm isAppointment={true} />
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AppointmentDialog;